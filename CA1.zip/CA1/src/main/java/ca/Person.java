package ca;

public class Person {

    String PPSN, name, DOB, Phone, Access;
    boolean complete;

    public Person (String PPSN, String name, String DOB, String Phone, String Access, boolean complete) {

        this.PPSN = PPSN;
        this.name = name;
        this.DOB = DOB;
        this.Phone = Phone;
        this.Access = Access;
        this.complete = complete;


    }

        /*

    --------------- GETTERS ------------
     */

    public String getPPSN() {
        return PPSN;
    }

    public String getName() {
        return name;
    }

    public String getAccess() {
        return Access;
    }

    public String getDOB() {
        return DOB;
    }

    public String getPhone() {
        return Phone;
    }

        /*

    --------------- SETTERS ------------
     */

    public void setPPSN(String PPSN) {
        this.PPSN = PPSN;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAccess(String access) {
        Access = access;
    }

    public void setDOB(String DOB) {
        this.DOB = DOB;
    }

    public void setPhone(String phone) {
        Phone = phone;
    }

       /*
    ------------------ METHODS ---------------------
     */

    @Override
    public String toString() {
        return "Person{" +
                "PPSN='" + PPSN + '\'' +
                ", name='" + name + '\'' +
                ", DOB='" + DOB + '\'' +
                ", Phone='" + Phone + '\'' +
                ", Access='" + Access + '\'' +
                ", complete=" + complete +
                '}';
    }
}
