package ca;

import java.io.*;


import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.DomDriver;
import com.thoughtworks.xstream.security.AnyTypePermission;

public class Main {

    FunkyList<VaccinationCentre> vaccinationCentreFunkyList;
    FunkyList<Person> personFunkyList;
    FunkyList<Appointments> completedAppointmentFunkyList;




    public Main() {

        personFunkyList = new FunkyList<>();
        vaccinationCentreFunkyList = new FunkyList<>();
        completedAppointmentFunkyList = new FunkyList<>();

        start();

}

// Loop for the smallest 91 - 83 type of thing.

public void start() {

//  vaccinationCentreFunkyList.addElement(new VaccinationCentre("W.I.T Sport Campus", "W.I.T Arena", "X91 K40Z", 10)); // Head
  //  vaccinationCentreFunkyList.addElement(new VaccinationCentre("Kilcohan Test Centre", "Kilcohan", "X91 K40Z", 10)); // Head
   // vaccinationCentreFunkyList.addElement(new VaccinationCentre("Portlaoise HSE Test Centre", "Portlaoise", "X91 K40Z", 10)); // Head
//   printVacCentre();
//    addBooth("A1", "Front", 8, 0);
  // addPerson("1234567X2","","","","",false);
  // addPerson("1234567X3","","","","",false);
   // addPerson("1234567X3","","","","",false);
   // addPerson("1234567X3","","","","",false);
   // System.out.println(printPeople());

    // All the above are loaded by the xml file.

    System.out.println(searchPPSN("1234567X2"));

    try {
        loadVacCentres();
        loadPerson();
        loadCompleted();
    } catch (Exception e) {
        System.out.println("doesnt work" + e);

    }

    //    System.out.println(searchPPSN("1234567X2"));
 //   addAppointment("2:00pm","","Moderna","Moderna","1234567XA",0,0, true);
   // addAppointment("","","Moderna","Moderna","1234567XA",0,0, true);
  //  System.out.println(searchVacType("Moderna").printList());
//    System.out.println(vaccinationCentreFunkyList.get(0).toString());
//    System.out.println(vaccinationCentreFunkyList.get(0).booths.get(0).toString());
//    System.out.println(vaccinationCentreFunkyList.get(0).booths.get(0).appointments.get(0).toString());
//    System.out.println(personFunkyList.get(0).toString());

    try {
        saveVacCentres();
        loadPerson();
        loadCompleted();
    } catch (Exception e) {
        System.out.println("doesnt work" + e);
    }

  //  System.out.println(vaccinationCentreFunkyList.get(0).booths.get(0).appointments.get(0).toString());
  //  addBooth("A4", 1, "Front", 0);
   // printVacCentre();
  //  addAppointment("A3", 2, "Front", 0);



}

    public static void main(String[] args) {


    new Main();


    }

    public void addVacCentre(String name, String address, String eircode, int spaces) {

        vaccinationCentreFunkyList.addElement(new VaccinationCentre(name,address,eircode,spaces));

    }

    public String printPeople() {


        int size;
        size = personFunkyList.size();


        for(int i=0;i<personFunkyList.size();i++){
            System.out.println(personFunkyList.get(i));
        }
        System.out.println("\n");
        return null;
    }


    public String printVacCentre() {


        int size;
        size = vaccinationCentreFunkyList.size();


        for(int i=0;i<vaccinationCentreFunkyList.size();i++){
            System.out.println(vaccinationCentreFunkyList.get(i));
        }
        System.out.println("\n");
        return null;
    }

    public String printBooths(int index) {

        VaccinationCentre vc1= vaccinationCentreFunkyList.get(index);

        for(int i=0;i<vc1.booths.size();i++){
            System.out.println(vc1.booths.get(i).toString());
        }
        return null;
    }


    public void removeVacCentre(int index) {
        VaccinationCentre vc1= vaccinationCentreFunkyList.get(index);



        vaccinationCentreFunkyList.remove(index);
        System.out.println(vaccinationCentreFunkyList.get(index));

    }

    public void addBooth(String UID, String accessibility, int level, int index) {
        VaccinationCentre vc1 = vaccinationCentreFunkyList.get(index);


      //  if (vc1.booths != null) {
        //    for (Booth b : vc1.booths) {

          //      if (UID.equals(b.getUID())) {

            //        System.out.println("This UID has already been used. ");


              //  } else if(!UID.equals(b.getUID())){

                    vc1.addBooth(UID, level, accessibility);

                }

    public void addPerson(String PPSN, String name, String DOB, String Phone, String Access, boolean complete) {


            personFunkyList.addElement(new Person(PPSN,name,DOB,Phone,Access,complete));


    }

    public FunkyList<Appointments> searchVacType(String vacType) {
        FunkyList<Appointments> appointmentsFunkyList;
        appointmentsFunkyList = new FunkyList<>();
        for (VaccinationCentre vc : vaccinationCentreFunkyList) {
            for (Booth bt : vc.booths) {
                for (Appointments ap : bt.appointments) {
                    if (ap.getVaccinationType().equals(vacType)) {
                        appointmentsFunkyList.addElement(ap);
                    }}}}

        return appointmentsFunkyList;

    }

    public FunkyList<Appointments> searchPPSNAppointment(String PPSN) {
        FunkyList<Appointments> PPSNAppointment;
        PPSNAppointment = new FunkyList<>();
        for (VaccinationCentre vc : vaccinationCentreFunkyList) {
            for (Booth bt : vc.booths) {
                for (Appointments ap : bt.appointments) {
                    if (ap.getPPSN().equals(PPSN)) {

                        PPSNAppointment.addElement(ap);
                    }}}}

        return PPSNAppointment;

    }

    public void addAppointment(String date, String time, String vaccinationType, String vaccinatorDetails, String PPSN, int indexVac, int indexBoo, boolean status) {
        VaccinationCentre vc1= vaccinationCentreFunkyList.get(indexVac);
        Booth bc1 = vc1.booths.get(indexBoo);
        bc1.addAppointment(date, time, vaccinationType,vaccinatorDetails,PPSN,status);


    }

    public void addCert(String date, String time, String vaccinationType, String vaccinatorDetails, String PPSN, int indexVac, int indexBoo, boolean status) {
        VaccinationCentre vc1= vaccinationCentreFunkyList.get(indexVac);
        Booth bc1 = vc1.booths.get(indexBoo);

        bc1.addAppointment(date, time, vaccinationType,vaccinatorDetails,PPSN,status);


    }

    public int searchPPSN(String PPSN) {

        int counter = 0;
        for (Person p : personFunkyList) {

            counter++;

            if (p.getPPSN().equals(PPSN)) {


                return counter;


            } else {

                System.out.println("Theres no person matching this PPSN");
            }


        }
        return -1;
    }


    public void removeBooth(int  indexVac, int indexBoo) {

        VaccinationCentre vc1= vaccinationCentreFunkyList.get(indexVac);
        System.out.println(vc1.toString());

   //     FunkyNode<Booth> bc = (FunkyNode<Booth>) boothFunkyList.get(indexBoo);
     //   Booth bc1 = bc.getContents();
        System.out.println(vc1.getBoothList());


    }



    public void loadVacCentres() throws IOException, ClassNotFoundException {

        XStream xstream = new XStream(new DomDriver());
        xstream.addPermission(AnyTypePermission.ANY);
        ObjectInputStream is = xstream.createObjectInputStream(new FileReader("vaccinations.xml"));
        vaccinationCentreFunkyList = (FunkyList<VaccinationCentre>) is.readObject();
        is.close();
    }




    public void saveVacCentres() throws IOException {

        XStream xstream = new XStream(new DomDriver());
        ObjectOutputStream out = xstream.createObjectOutputStream(new FileWriter("vaccinations.xml"));
        out.writeObject(vaccinationCentreFunkyList);
        out.close();

    }

    public void savePerson() throws IOException {

        XStream xstream = new XStream(new DomDriver());
        ObjectOutputStream out = xstream.createObjectOutputStream(new FileWriter("person.xml"));
        out.writeObject(personFunkyList);
        out.close();

    }

    public void loadPerson() throws IOException, ClassNotFoundException {

        XStream xstream = new XStream(new DomDriver());
        xstream.addPermission(AnyTypePermission.ANY);
        ObjectInputStream is = xstream.createObjectInputStream(new FileReader("person.xml"));
        personFunkyList = (FunkyList<Person>) is.readObject();
        is.close();
    }

    public void saveCompleted() throws IOException {

        XStream xstream = new XStream(new DomDriver());
        ObjectOutputStream out = xstream.createObjectOutputStream(new FileWriter("completed.xml"));
        out.writeObject(completedAppointmentFunkyList);
        out.close();

    }

    public void loadCompleted() throws IOException, ClassNotFoundException {

        XStream xstream = new XStream(new DomDriver());
        xstream.addPermission(AnyTypePermission.ANY);
        ObjectInputStream is = xstream.createObjectInputStream(new FileReader("completed.xml"));
        completedAppointmentFunkyList = (FunkyList<Appointments>) is.readObject();
        is.close();
    }


}
