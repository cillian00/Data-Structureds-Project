package ca;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class BoothController {

@FXML
private TextField UID;
    @FXML
    private TextField Level;
    @FXML
    private TextField Accessibility;
    @FXML
    private TextField Index;

    @FXML
    private Label UID1; // UID Label
    @FXML
    private Label Level1; // Address Label
    @FXML
    private Label Index1; // Address Label
    @FXML
    private Label Accessibility1; // NoOfParkingSpaces Label
    @FXML
    private Button but; // Submit button
    @FXML
    private Button next; // Submit button
    @FXML
    private Button delete; // Submit button
    @FXML
    private ListView list;
    @FXML
    private ListView vacList;

    private Main mc;



    public BoothController() {


        start();

    }

    public void start() {

    }

    @FXML
    public void initialize() {

        for (int index = 0; ApplicationV.mc.vaccinationCentreFunkyList.size() > index; index++)
        vacList.getItems().addAll(new Label("#" + index + " " + ApplicationV.mc.vaccinationCentreFunkyList.get(index).toString()));



    }

@FXML
    public void delete() {


    int indexVac = vacList.getSelectionModel().getSelectedIndex();

            if(vacList.getSelectionModel().getSelectedIndex()>=0) {

                vacList.getItems().remove(vacList.getSelectionModel().getSelectedIndex());

                ApplicationV.mc.removeVacCentre(indexVac);

            }


    int indexBooth = list.getSelectionModel().getSelectedIndex(); // Booth Index
    int i = Integer.parseInt(Index.getText());

       if(list.getSelectionModel().getSelectedIndex()>=0) {

            list.getItems().remove(list.getSelectionModel()
                        .getSelectedIndex());
       }

    ApplicationV.mc.vaccinationCentreFunkyList.get(i).removeBooth(indexBooth);


    }



       public void next() throws Exception {

           FXMLLoader loader = new FXMLLoader(getClass().getResource("/Person.fxml"));
           Parent root = loader.load();

           Stage window = (Stage) but.getScene().getWindow();
           window.setScene(new Scene(root, 1119, 750));


       }

    public void handleScene() throws Exception{


        Parent root = FXMLLoader.load(ApplicationV.class.getResource("/CA#2.fxml"));

        Stage window = (Stage) but.getScene().getWindow();
        window.setScene(new Scene(root, 1119, 750));


    }

    @FXML public void mainMenu(ActionEvent e) throws Exception{

        FXMLLoader loader = new FXMLLoader(getClass().getResource("/Main.fxml"));
        Parent root = loader.load();

        Stage window = (Stage) but.getScene().getWindow();
        window.setScene(new Scene(root, 1119, 750));


    }

    @FXML
    private void save(ActionEvent e) {

        try {
            ApplicationV.mc.saveVacCentres();
        } catch(Exception E) {

            System.out.println("Can't save!");


        }



    }

    @FXML private void submitBut(ActionEvent e){

        int index = Integer.parseInt(Index.getText());
        String names = UID.getText();
        Boolean u = true;

            for(Booth bt : ApplicationV.mc.vaccinationCentreFunkyList.get(index).booths) {

                if(bt.getUID().equals(names)) {

                    UID1.setText("This UID has already been used");
                    u = false;

                }


            }




        UID1.setText("UID:" + " " + names);
        String acc = Accessibility.getText();
        Accessibility1.setText("Accessibility:" + " " + acc);

        if((index > ApplicationV.mc.vaccinationCentreFunkyList.size() ) || ( index < 0) || (ApplicationV.mc.vaccinationCentreFunkyList.size() == index)) {


            Index1.setText("The index you've chosen is out of range");
        } else
            Index1.setText("Index: " + index);

        if(Level.getText().matches("[0-9]{1,2}")) {

            String numbers = Level.getText();
            Level1.setText("Level" + " " + numbers);


        } else {

            Level1.setText("Please Enter Numbers Only" );

        }

        if
        (Level.getText().matches("[0-9]{1,2}") &&
                (index < ApplicationV.mc.vaccinationCentreFunkyList.size())
        && u) {





            list.getItems().addAll(new Label("New Booth --> "+ "UID: " + UID.getText() + "  Accessibility: " + Accessibility.getText() + "  Level: " + Level.getText() + " Vac Index: " + index));

            int i = Integer.parseInt(Level.getText());
           addBooth(UID.getText(),Accessibility.getText(),i,index);

        }


    }

    private void addBooth(String UID, String address, int spaces, int index) {

        ApplicationV.mc.addBooth(UID,address,spaces,index);

    }


    @Override
    public String toString() {
        return "BoothController{" +
                "UID=" + UID +
                ", Level=" + Level +
                ", Accessibility=" + Accessibility +
                '}';
    }
}