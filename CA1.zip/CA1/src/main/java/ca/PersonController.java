package ca;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

public class PersonController {


    @FXML
    private TextField PPSN;
    @FXML
    private TextField Name;
    @FXML
    private TextField Accessibility;
    @FXML
    private TextField Phone;
    @FXML
    private Label PPSN1; // UID Label
    @FXML
    private Label Name1; // Address Label
    @FXML
    private Label Accessibility1;
    @FXML
    private Label DOB1;
    @FXML
    private Label Phone1; // NoOfParkingSpaces Label
    @FXML
    private DatePicker DOB; // Date Picker Date of Birth.
    @FXML
    private Button but; // Submit button
    @FXML
    private ListView list;

    private Main mc;



    public PersonController() {


        start();

    }

    public void start() {

    }

    @FXML
    public void initialize() {

    }

    public void handleScene() throws Exception{


        Parent root = FXMLLoader.load(ApplicationV.class.getResource("/CA#2.fxml"));

        Stage window = (Stage) but.getScene().getWindow();
        window.setScene(new Scene(root, 1119, 750));


    }

    @FXML public void mainMenu(ActionEvent e) throws Exception{

        FXMLLoader loader = new FXMLLoader(getClass().getResource("/Main.fxml"));
        Parent root = loader.load();

        Stage window = (Stage) but.getScene().getWindow();
        window.setScene(new Scene(root, 1119, 750));


    }



    @FXML private void submitBut(ActionEvent e){

        String names = PPSN.getText();


            PPSN1.setText("PPSN:" + " " + names + " ");

        String realname = Name.getText();


        Name1.setText("Name:" + " " + realname + " ");


        String acc = Accessibility.getText();
        Accessibility1.setText("Accessibility:" + " " + acc);
        DOB1.setText("Date of Birth:" + " " + DOB.getValue());

        if(Phone.getText().matches("[0-9]{10}")) {

            String numbers = Phone.getText();
            Phone1.setText("Level" + " " + numbers);


        } else {

            Phone1.setText("Please Enter Numbers Only" + " 10 Numbers. " );

        }

        if
        (Phone.getText().matches("[0-9]{10}")) {


            list.getItems().addAll(new Label("New Person --> "+ "PPSN: " + PPSN.getText() + " Name: " + Name.getText() + "  Phone: " + Phone.getText() +  "  DOB: " + DOB.getValue() + "  Accessibility: " + Accessibility.getText()));

            int i = Integer.parseInt(Phone.getText());

        }

        String dob = ("" + DOB.getValue());

        ApplicationV.mc.addPerson(PPSN.getText(),Name.getText(),dob,Phone.getText(),Accessibility.getText(), false);


    }



}