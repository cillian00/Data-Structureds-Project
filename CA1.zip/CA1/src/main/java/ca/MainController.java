package ca;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class MainController {

@FXML
private Button vac;
    @FXML
    private Button boo;
    @FXML
    private Button boo1;
    @FXML
    private Button boo12;
    @FXML
    private Button but123;
    @FXML
    private Button list;
    @FXML
    private Button reset;


    public MainController() {


        start();

    }

    public void start() {

    }

    @FXML
    public void initialize() {


    }

    @FXML
    public void vacButton() throws Exception {

        FXMLLoader loader = new FXMLLoader(getClass().getResource("/Vaccination.fxml"));
        Parent root = loader.load();


        Stage window = (Stage) vac.getScene().getWindow();
        window.setTitle("Vaccination Centre Creator");

        window.setScene(new Scene(root, 1119, 750));

     //   VacController vacController=loader.getController();
      //  vacController.vaccinationCentreFunkyList.size();

    }

    public void bootButton() throws Exception {

        FXMLLoader loader = new FXMLLoader(getClass().getResource("/Booth.fxml"));
        Parent root = loader.load();


        Stage window = (Stage) boo.getScene().getWindow();
        window.setTitle("Booth Creator");
        window.setScene(new Scene(root, 1119, 750));

        //   VacController vacController=loader.getController();
        //  vacController.vaccinationCentreFunkyList.size();

    }


    public void personButton() throws Exception {

        FXMLLoader loader = new FXMLLoader(getClass().getResource("/Person.fxml"));
        Parent root = loader.load();



        Stage window = (Stage) boo1.getScene().getWindow();
        window.setTitle("Booth Creator");
        window.setScene(new Scene(root, 1119, 750));

        //   VacController vacController=loader.getController();
        //  vacController.vaccinationCentreFunkyList.size();

    }

    public void appointmentButton() throws Exception {

        if (ApplicationV.mc.vaccinationCentreFunkyList.size() > 0) {

            FXMLLoader loader = new FXMLLoader(getClass().getResource("/Appointment.fxml"));
            Parent root = loader.load();


            Stage window = (Stage) boo12.getScene().getWindow();
            window.setTitle("Appointment Creator");
            window.setScene(new Scene(root, 1119, 750));

            //   VacController vacController=loader.getController();
            //  vacController.vaccinationCentreFunkyList.size();

        } else {
            System.out.println("There are no Vaccination centres for appointments to be made!");
        }
    }

    public void searchButton() throws Exception {

        FXMLLoader loader = new FXMLLoader(getClass().getResource("/VacSearch.fxml"));
        Parent root = loader.load();



        Stage window = (Stage) but123.getScene().getWindow();
        window.setTitle("Search");
        window.setScene(new Scene(root, 1119, 750));

        //   VacController vacController=loader.getController();
        //  vacController.vaccinationCentreFunkyList.size();

    }


@FXML
    public void listButton() throws Exception {

        FXMLLoader loader = new FXMLLoader(getClass().getResource("/List.fxml"));
        Parent root = loader.load();



        Stage window = (Stage) list.getScene().getWindow();
        window.setTitle("Search");
        window.setScene(new Scene(root, 1119, 750));

        //   VacController vacController=loader.getController();
        //  vacController.vaccinationCentreFunkyList.size();

    }

    @FXML
    private void save() {

        try {
            ApplicationV.mc.saveVacCentres();
            ApplicationV.mc.savePerson();
            ApplicationV.mc.saveCompleted();
        } catch(Exception E) {

            System.out.println("Can't save!");


        }



    }

    public void resetButton() throws Exception {



        FXMLLoader loader = new FXMLLoader(getClass().getResource("/resetButton.fxml"));
        Parent root = loader.load();


        System.out.println("Vac Center Size = " + ApplicationV.mc.vaccinationCentreFunkyList.size());
        System.out.println("Booth Size = " + ApplicationV.mc.vaccinationCentreFunkyList.get(0).booths.size());
        System.out.println("Appointments = " + ApplicationV.mc.vaccinationCentreFunkyList.get(0).booths.get(0).appointments.size());


        Stage window = (Stage) reset.getScene().getWindow();
        window.setTitle("WARNING");
        window.setScene(new Scene(root, 1119, 750));

        //   VacController vacController=loader.getController();
        //  vacController.vaccinationCentreFunkyList.size();

    }


}