package ca;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;


public class ListController {

    @FXML
    private TextField PPSN;
    @FXML
    private TextField vac;
    @FXML
    private TextField app;
    @FXML
    private TextField booth;
    @FXML
    private CheckBox cp;
    @FXML
    private ChoiceBox Type;
    @FXML
    private Button but; // Menu button
    @FXML
    private Button clear; // Submit button
    @FXML
    private Button but1; // Submit button
    @FXML
    private Button but12; // Submit button
    @FXML
    private TextField text;
    @FXML
    private TextField text1;
    @FXML
    private Label check;
    @FXML
    private Label check1;
    @FXML
    private ListView<Label> list;

    int i, i2,i3;
    private Main mc;
    private ApplicationV v;

    private int deleteIndex;

    public ListController() {


        start();

    }

    public void start() {


    }

    @FXML
    public void initialize() {

        list.getItems().clear();

    }

    @FXML
    private void submitBut2(ActionEvent e) {


    }


    @FXML
    private void submitBut1(ActionEvent e) {

        int CentreSize = ApplicationV.mc.vaccinationCentreFunkyList.size();


        String string = text.getText(); // We get our string first.
        String string2, string3;


        if (string.matches("[^-0-9]")) {

            System.out.println(string);
            check.setText("Please enter integers only. ");

        }

        if (string.length() > 3 || string.equals("")) { // Check if it's valid.

            check.setText("This is out of bounds. 3 integers is the max.");

        } else {


            int c;
            string = string.substring(0, 1); // Centre
            c = Integer.parseInt(string);


            int boothSize = ApplicationV.mc.vaccinationCentreFunkyList.get(c).booths.size();
            int b;
            string2 = string.substring(1); // booth
            //   b = Integer.parseInt(string2);
            System.out.println("booth = " + string2);

            if (string.length() == 1) {

                if (CentreSize > c) {

                    list.getItems().addAll(new Label("#" + c + " " + ApplicationV.mc.vaccinationCentreFunkyList.get(c).toString()));


                } else if (c == CentreSize) {

                    check.setText("Your Centre Index is out of range!");

                }
            }

            // String.length == 1


            //   } else if (b <= boothSize) {

            //        check.setText("Your Booth Index is out of range!");
            //   }
        }

    }


    @FXML
    public void listAppointments(ActionEvent e) {

        deleteIndex = 3;
        list.getItems().clear();

        System.out.println(ApplicationV.mc.vaccinationCentreFunkyList.get(0).booths.get(0).appointments.size());
        //System.out.println(ApplicationV.ac.completedAppointmentsFunkyList.size());

        boolean isSelected = cp.isSelected();

        if (!isSelected) {
            for (VaccinationCentre vc : ApplicationV.mc.vaccinationCentreFunkyList) {
                for (Booth bt : vc.booths) {
                    for (Appointments ap : bt.appointments) {
                        list.getItems().addAll(new Label("New :" + ap.toString()));
                    }
                }
            }

        } else {

            for (int i = 0; i < ApplicationV.ac.completedAppointmentsFunkyList.size(); i++) {
                System.out.println(ApplicationV.ac.completedAppointmentsFunkyList.get(i).toString());
                list.getItems().addAll(new Label("New :" + ApplicationV.ac.completedAppointmentsFunkyList.get(i).toString()));
            }
        }
    }

    @FXML
    public void listPPSNAppointments(ActionEvent e) {

        list.getItems().clear();
        String ppsn = text1.getText();
        System.out.println("Search");

        for (VaccinationCentre vc : ApplicationV.mc.vaccinationCentreFunkyList) {
            for (Booth bt : vc.booths) {
                for (Appointments ap : bt.appointments) {
                    if (ap.getPPSN().equals(ppsn)) {
                        list.getItems().addAll(new Label("New :" + ap));
                    } else {
                        System.out.println("No PPSN detected.");
                    }
                }
            }
        }
    }


    @FXML
    public void listVacCentres(ActionEvent e) {

        deleteIndex = 0;
        list.getItems().clear();

        for (int i = 0; i < ApplicationV.mc.vaccinationCentreFunkyList.size(); i++) {
            System.out.println(ApplicationV.mc.vaccinationCentreFunkyList.get(i));
            list.getItems().addAll(new Label(ApplicationV.mc.vaccinationCentreFunkyList.get(i).toString()));
        }

    }

    @FXML
    public void listBooths(ActionEvent e) {

        deleteIndex = 1;
        list.getItems().clear();

        for (VaccinationCentre vc : ApplicationV.mc.vaccinationCentreFunkyList) {
            for (Booth bt : vc.booths) {
                list.getItems().addAll(new Label(" " + bt.toString()));

            }
        }
    }

    @FXML
    public void listBooth(ActionEvent e) {

        deleteIndex = 1;
        String b = booth.getText();
        if (b.length() == 2) {
            String b1 = b.substring(0, 1);
            int i = Integer.parseInt(b1);
            System.out.println(i);
            String b2 = b.substring(1, 2);
            int i2 = Integer.parseInt(b2);
            System.out.println(i2);

            if (ApplicationV.mc.vaccinationCentreFunkyList.get(i).booths.get(i2).toString() == null) {
                System.out.println("Nope");
            } else {
                list.getItems().addAll(new Label("New --> " + ApplicationV.mc.vaccinationCentreFunkyList.get(i).booths.get(i2).toString()));


            }
        }
    }


    @FXML
    public void listAppointment(ActionEvent e) {

        String a = app.getText();
        if (a.length() == 3) {
            String a1 = a.substring(0,1);
            i = Integer.parseInt(a1);
            System.out.println(i);
            String a2 = a.substring(1,2);
            i2 = Integer.parseInt(a2);
            System.out.println(i2);
            String a3 = a.substring(2,3);
            i3 = Integer.parseInt(a3);
            System.out.println(i3);

            list.getItems().addAll(new Label("New --> " + ApplicationV.mc.vaccinationCentreFunkyList.get(i).booths.get(i2).appointments.get(i3).toString()));


        }
    }


    @FXML
    public void listPersons(ActionEvent e) {

        deleteIndex = 4;
        list.getItems().clear();

        for (Person p : ApplicationV.mc.personFunkyList) {
            list.getItems().addAll(new Label(" " + p.toString()));

        }
    }

    @FXML
    public void listPerson(ActionEvent e) {

        String ppsn = text1.getText();
        for (Person p : ApplicationV.mc.personFunkyList) {
            if (p.getPPSN().equals(ppsn)) {
                list.getItems().addAll(new Label(" " + p.toString()));

            }
        }
    }

    @FXML
    private void clear(ActionEvent e) {


        list.getItems().clear();

    }

    @FXML
    public void seachPPSN(String ppsn) {

        int i = ApplicationV.mc.searchPPSN(ppsn);


        list.getItems().addAll(new Label("" + ApplicationV.mc.personFunkyList.get(i).toString()));
    }


    @FXML
    public void mainMenu(ActionEvent e) throws Exception {

        FXMLLoader loader = new FXMLLoader(getClass().getResource("/Main.fxml"));
        Parent root = loader.load();

        Stage window = (Stage) but1.getScene().getWindow();
        window.setScene(new Scene(root, 1119, 750));


    }

    @FXML
    public void delete(ActionEvent e) throws Exception {

        if (deleteIndex == 0) {// Vac Centres

            int vacIndex = list.getSelectionModel().getSelectedIndex(); // Booth Index

            if (vacIndex >= 0) {

                list.getItems().remove(vacIndex);

                ApplicationV.mc.removeVacCentre(vacIndex);


            }


        } else if (deleteIndex == 1) { // Booths

            int boothIndex = list.getSelectionModel().getSelectedIndex(); // Booth Index

            if (boothIndex >= 0) {

                list.getItems().remove(boothIndex);

                ApplicationV.mc.vaccinationCentreFunkyList.get(i).booths.remove(boothIndex);


            }


        } else if (deleteIndex == 2) { // Appointments


        } else if (deleteIndex == 3) { // Completed

            int completeIndex = list.getSelectionModel().getSelectedIndex(); // Booth Index

            if (completeIndex >= 0) {

                list.getItems().remove(completeIndex);

                ApplicationV.mc.completedAppointmentFunkyList.remove(completeIndex);


            }


        } else if (deleteIndex == 4) { // Persons


            int personIndex = list.getSelectionModel().getSelectedIndex(); // Booth Index

            if (personIndex >= 0) {

                list.getItems().remove(personIndex);

                ApplicationV.mc.personFunkyList.remove(personIndex);


            }
        }
    }
}





