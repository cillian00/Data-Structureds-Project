package ca;

import ca.FunkyNode;

import java.util.Iterator;

public class FunkyIterator<K> implements Iterator<K> {
    private FunkyNode<K> pos; //Current position

    public FunkyIterator(FunkyNode<K> fnode) {
        pos = fnode;
    }

    @Override
    public boolean hasNext() {
        return pos != null;
    }

    @Override
    public K next() {
        FunkyNode<K> temp = pos;
        pos = pos.next;
        return temp.getContents();
    }
}
