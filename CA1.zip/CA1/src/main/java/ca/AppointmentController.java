package ca;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.time.LocalDate;

public class AppointmentController {

    FunkyList<Appointments> completedAppointmentsFunkyList;

    @FXML
private TextField PPSN;
    @FXML
    private TextField Time;
    @FXML
    private TextField vacDetails;
    @FXML
    private ChoiceBox<String> vacType;
    @FXML
    private DatePicker date;
    @FXML
    private TextField vacIndex;
    @FXML
    private TextField boothIndex;
    @FXML
    private Label Time1; // UID Label
    @FXML
    private Label vacDetails1;
    @FXML
    private Label vacType1;
    @FXML
    private Label PPSN1; // Address Label
    @FXML
    private Label vacIndex1; // Address Label
    @FXML
    private Label boothIndex1; // Address Label
    @FXML
    private Label Accessibility1; // NoOfParkingSpaces Label
    @FXML
    private Button complete;
    @FXML
    private Button but; // Submit button
    @FXML
    private ListView<Label> list;
    @FXML
    private ListView<Label> vacList;
    @FXML
    private ListView<Label> boothList;

    private Main mc;



    public AppointmentController() {

        completedAppointmentsFunkyList = new FunkyList<>();


        start();

    }

    public void start() {

    }

    @FXML
    public void initialize() throws Exception {

        secondAppointment();
        vacType.getItems().addAll("BioNTech-Pfizer", "Moderna", "AstraZeneca", "Janssen/J&J");


        if (ApplicationV.mc.vaccinationCentreFunkyList.get(0) == null) {


        }
        for (int index = 0; ApplicationV.mc.vaccinationCentreFunkyList.size() > index; index++) {
            vacList.getItems().addAll(new Label("#" + index + " " + ApplicationV.mc.vaccinationCentreFunkyList.get(index).toString()));
        }
    }
    @FXML public void mainMenu(ActionEvent e) throws Exception{

        FXMLLoader loader = new FXMLLoader(getClass().getResource("/Main.fxml"));
        Parent root = loader.load();

        Stage window = (Stage) but.getScene().getWindow();
        window.setScene(new Scene(root, 1119, 750));

    }

    @FXML private void checkBooths(ActionEvent e) {

        if (vacIndex.getText().matches("[0-9]{1,2}")) {
            int l = Integer.parseInt(vacIndex.getText());

            for (int i = 0; ApplicationV.mc.vaccinationCentreFunkyList.get(l).booths.size() > i; i++) {
                VaccinationCentre vc1= ApplicationV.mc.vaccinationCentreFunkyList.get(l);
                boothList.getItems().addAll(new Label("#" + i + " " + vc1.booths.get(i).toString()));
            }
        }
    }

    @FXML
    private void addAppointment(ActionEvent e) {

        int index = Integer.parseInt(vacIndex.getText());

        String names = PPSN.getText();
        //    if (ApplicationV.mc.searchPPSN(names) > -1) {

        PPSN1.setText("PPSN:" + " " + names);

        //  } else {

        //       PPSN1.setText("This PPSN does not exist.");
        //    }
        boolean legit = false;
        for (Person p : ApplicationV.mc.personFunkyList) {
            if (p.getPPSN().equals(names)) {

                System.out.println("PPSN Is legit.");
                legit = true;
            }
            System.out.println("Theres no person matching this PPSN");


        }
        String acc = vacDetails.getText();
        vacDetails1.setText("Vac Details:" + " " + acc);

        if ((index > ApplicationV.mc.vaccinationCentreFunkyList.size()) || (index < 0) || (ApplicationV.mc.vaccinationCentreFunkyList.size() == index)) {

            vacIndex1.setText("The index you've chosen is out of range");

        } else {
            vacIndex1.setText("Index: " + index);

        }

        int bIndex = Integer.parseInt(boothIndex.getText());

        if ((bIndex >= ApplicationV.mc.vaccinationCentreFunkyList.get(index).booths.size()) || (index < 0)) {


            vacIndex1.setText("The index you've chosen is out of range");

        } else {
            vacIndex1.setText("Index: " + bIndex);

        }


        if (legit) { // if PPSN matches
            list.getItems().addAll(new Label("New Appointment --> " + " VIndex #" + vacIndex.getText() + " BIndex #" + boothIndex.getText() + "  PPSN: " + PPSN.getText() + "|" + "   VacType: " + vacType.getValue() + "|" + "   vacDetails: " + vacDetails.getText() + "|" + "  Date: " + date.getValue() + "|" + "  Time:" + Time.getText() + "|"));


            String da = ("" + date.getValue()); // Date
            System.out.println(da);
            int v = Integer.parseInt(vacIndex.getText());
            int b = Integer.parseInt(boothIndex.getText());
            // date, time, vacType, vacDetails, PPSN, Vindex, Bindex, status:
            ApplicationV.mc.addAppointment(da, Time.getText(), vacType.getValue(), vacDetails.getText(), PPSN.getText(), v, b, false); // First Appointment

            list.getItems().addAll(new Label("Second Appointment date set! --> " + " VIndex #" + vacIndex.getText() + " BIndex #" + boothIndex.getText() + "  PPSN: " + PPSN.getText() + "|" + "   VacType: " + vacType.getValue() + "|" + "   vacDetails: " + vacDetails.getText() + "|" + "  Date: " + date.getValue() + "|" + "  Time:" + Time.getText() + "|"));

            LocalDate second = date.getValue().plusDays(30); // second date
            System.out.println(second);
            String da2 = ("" + second); // Date
            ApplicationV.mc.addAppointment(da2, Time.getText(), vacType.getValue(), vacDetails.getText(), PPSN.getText(), v, b, false); // 2nd Appointment


        }
    }

        private void secondAppointment() {

            System.out.println(ApplicationV.mc.vaccinationCentreFunkyList.get(0).booths.size());

        }

        @FXML
    private void completeAppointment(ActionEvent e) {

            int appointmentIndex = list.getSelectionModel().getSelectedIndex(); // Booth Index
            int v = Integer.parseInt(vacIndex.getText());

            if(list.getSelectionModel().getSelectedIndex()>=0) {

                list.getItems().remove(list.getSelectionModel()
                        .getSelectedIndex());
            }

           int b = Integer.parseInt(boothIndex.getText()); // Change String --> Int

            ApplicationV.mc.vaccinationCentreFunkyList.get(v).booths.get(b).appointments.get(appointmentIndex).setStatus(true); // Telling the appointment that it's been completed.

            completedAppointmentsFunkyList.addElement(ApplicationV.mc.vaccinationCentreFunkyList.get(v).booths.get(b).appointments.get(appointmentIndex)); // Add it to the list.

            ApplicationV.mc.vaccinationCentreFunkyList.get(v).booths.get(b).appointments.remove(appointmentIndex); // Remove it from the previous list.

            // Above gets rid of it from the list.

            System.out.println(completedAppointmentsFunkyList.get(0)); // show the new appointment

            System.out.println(completedAppointmentsFunkyList.size()); // check it's size




        }

        @FXML
        private void save(ActionEvent e) {

        try {
            ApplicationV.mc.saveVacCentres();
        } catch(Exception E) {

            System.out.println("Can't save!");


            }
        }




}