package ca;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class resetButtonController {



    private Main mc;
    @FXML
    private Button confirm;
    @FXML
    private Button cancel;



    public resetButtonController() {


        start();

    }

    public void start() {

    }

    @FXML
    public void initialize() {





    }

    @FXML
    public void confirm() throws Exception {


        ApplicationV.mc.vaccinationCentreFunkyList.clear();
        ApplicationV.mc.personFunkyList.clear();

        FXMLLoader loader = new FXMLLoader(getClass().getResource("/Main.fxml"));
        Parent root = loader.load();

        Stage window = (Stage) confirm.getScene().getWindow();
        window.setScene(new Scene(root, 1119, 750));

        System.out.println("Reset....  COMPLETE");
        System.out.println("\nVac Center Size = " + ApplicationV.mc.vaccinationCentreFunkyList.size());
        if (ApplicationV.mc.vaccinationCentreFunkyList.size() > 0) {
            System.out.println("Booth Size = " + ApplicationV.mc.vaccinationCentreFunkyList.get(0).booths.size());

            System.out.println("Appointments = " + ApplicationV.mc.vaccinationCentreFunkyList.get(0).booths.get(0).appointments.size());
        }


    }

    @FXML
    public void cancel() throws Exception {

        FXMLLoader loader = new FXMLLoader(getClass().getResource("/Main.fxml"));
        Parent root = loader.load();

        Stage window = (Stage) cancel.getScene().getWindow();
        window.setScene(new Scene(root, 1119, 750));

        System.out.println(ApplicationV.mc.vaccinationCentreFunkyList.size());


    }

}