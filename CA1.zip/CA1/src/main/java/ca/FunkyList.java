package ca;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class FunkyList<F> implements List<F> {
        public FunkyNode<F> head=null;

    public FunkyList() {
    }

    public void addElement(F e) { //Add element to head of list
            FunkyNode<F> fn=new FunkyNode<>();
            fn.setContents(e);
            fn.next=head;
            head=fn;
        }

        public String printList() {

            FunkyNode currentNode = head;
            String list = "";
            while(currentNode != null) { // Checks if the next node is null, if so it stops. Otherwise keeps going to find the current node.

                list = list + currentNode.getContents() + "\t";
                currentNode = currentNode.next;
            }
            return list;

        }



    @Override
    public int size() {
        int size = 0;
        FunkyNode currentnode = head;
        while(currentnode != null)
        {
            size = size + 1;
            currentnode = currentnode.next;
        }

        return size;

    } // for every element we add 1

    @Override
    public boolean isEmpty() {

        FunkyNode currentNode = head;

        if (currentNode == null) {

            return true;
        }

        return false;
    }

    @Override
    public boolean contains(Object o) {
        return false;
    }


    @Override
    public Iterator<F> iterator() {
        return new FunkyIterator<F>(head);
    }


    @Override
    public Object[] toArray() {
        return new Object[0];
    }

    @Override
    public boolean add(Object o) {
        return false;
    }

    @Override
    public boolean remove(Object o) {
        return false;
    }

    @Override
    public boolean addAll(Collection c) {
        return false;
    }

    @Override
    public boolean addAll(int index, Collection c) {
        return false;
    }

    @Override
    public boolean retainAll(Collection c) {
        return false;
    }

    @Override
    public boolean removeAll(Collection c) {
        return false;
    }

    @Override
    public boolean containsAll(Collection c) {
        return false;
    }

    @Override
    public Object[] toArray(Object[] a) {
        return new Object[0];
    }

    public void clear() { //Empty list
            head=null;
        }

    @Override
    public F get(int index) {
       if (index == 0) {

           return (F) head.getContents();
       } else { 
           FunkyNode<F> currentNode = head;
           int counter = 0;
           while(currentNode != null && counter < index) { // Checks if the next node is null, if so it stops. Otherwise keeps going to find the current node.


               currentNode = currentNode.next;
               counter
                       ++;
           }
           return (F) currentNode.getContents();
       }
    }

    @Override
    public Object set(int index, Object element) {
        return null;
    }

    @Override
    public void add(int index, Object element) {

    }

    @Override
    public F remove(int index) {
        FunkyNode<F> currentNode = head;
        if(index == 0) {
            head = currentNode.next;

        } else {
            int counter = 0;
            while(counter < index-1) {
                currentNode = currentNode.next;
                counter++;
                remove(currentNode.next);
            }
            currentNode.next = currentNode.next.next;
        }
       return null;
    }

    @Override
    public int indexOf(Object o) {
        return 0;
    }

    @Override
    public int lastIndexOf(Object o) {
        return 0;
    }

    @Override
    public ListIterator listIterator() {
        return null;
    }

    @Override
    public ListIterator listIterator(int index) {
        return null;
    }

    @Override
    public List subList(int fromIndex, int toIndex) {
        return null;
    }

    public boolean search(FunkyNode head, String x)
    {
        FunkyNode current = head;    //Initialize current
        while (current != null)
        {
            if (current.getContents().equals(x))
                return true;    //data found
            current = current.next;
        }
        return false;    //data not found
    }


    //Add other insertion, deletion, access, search, etc. methods too
//Inner class approach.

}
