package ca;

public class Cert {

    private final String yes;

    public Cert(String yes ) {

        this.yes = yes;
        
    }
}
