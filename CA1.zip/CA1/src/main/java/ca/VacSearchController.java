package ca;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;


public class VacSearchController {

@FXML
private TextField PPSN;
    @FXML
    private ChoiceBox Type;
    @FXML
    private Label Name1; // Name Label
    @FXML
    private Label Address1; // Address Label
    @FXML
    private Label Eircode1; // Eircode Label
    @FXML
    private Label noOfParkingSpaces1; // NoOfParkingSpaces Label
    @FXML
    private Button but; // Submit button
    @FXML
    private ListView<Label> list;

    private Main mc;
    private ApplicationV v;


    public VacSearchController() {


        start();

    }

    public void start() {

    }

    @FXML
    public void initialize() {

        Type.getItems().addAll("BioNTech-Pfizer", "Moderna", "=AstraZeneca", "Janssen/J&J");
        System.out.println(v.mc.vaccinationCentreFunkyList.size());


    }


    @FXML
    private void submitBut(ActionEvent e) {


      //  if (vaccinationCentreFunkyList.size() == 0) {



            if (Type != null) {

                searchType();
            }

    //    } else {   // Once we established that the array is greater than 0, we can run checks.

      //      while (vaccinationCentreFunkyList.size() > 0) {
        //        int i = 0;
          //      i++;

            //    if (vaccinationCentreFunkyList.get(i).getName().equals(name.getText())) {

              //      na.setText("Name has already been used.");
                //    start();

                }
               // else {
                 //   addition();
            //    }
          //  }
        //}
    //}


    @FXML public void mainMenu(ActionEvent e) throws Exception{

        FXMLLoader loader = new FXMLLoader(getClass().getResource("/Main.fxml"));
        Parent root = loader.load();

        Stage window = (Stage) but.getScene().getWindow();
        window.setScene(new Scene(root, 1119, 750));


    }

    @FXML public void clear(ActionEvent e) {


        list.getItems().clear();


    }

    @FXML
    public void searchType() {

        list.getItems().clear();
        String type = "" + Type.getValue();

        if (type.length() == 7) {

        }
        System.out.println(type);
        System.out.println("Moderna");
        System.out.println(ApplicationV.mc.searchVacType(type).printList());


        for (int i = 0; ApplicationV.mc.searchVacType(type).size() > i; i++) {
            list.getItems().addAll(new Label("New Appointment: --> " + ApplicationV.mc.searchVacType(type).get(i).toString()));

        }

        String ppsn = PPSN.getText();
            int i = ApplicationV.mc.searchPPSN(ppsn);
            System.out.println(i);
            i--;

         //   list.getItems().addAll(new Label("" + ApplicationV.mc.personFunkyList.get(i).toString()));

        for (int l = 0; ApplicationV.mc.searchPPSNAppointment(ppsn).size() > l; l++) {

            list.getItems().addAll(new Label("New Appointment: --> " + ApplicationV.mc.searchPPSNAppointment(ppsn).get(l).toString()));

        }


    }


        }






