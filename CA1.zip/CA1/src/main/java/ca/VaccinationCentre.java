package ca;

public class VaccinationCentre {

    String name;
    String address;
    String eircode;

    int noOfParkingSpaces;
    FunkyList<Booth> booths;

    public VaccinationCentre(String name, String address, String eircode, int noOfParkingSpaces) {

        this.name = name;
        this.address = address;
        if(eircode.length() == 8 && eircode.substring(0, 3).matches("[A-Z][0-9]{2}")) {

            this.eircode = eircode;

        } else {

            this.eircode = "Wrong";
        }
        this.noOfParkingSpaces = noOfParkingSpaces;
        booths = new FunkyList<>();
    }







    /*

--------------- GETTERS ------------
*/

    
    public FunkyList<Booth> getBooths(int index) {
        return booths;
    }

    public int getNoOfParkingSpaces() {
        return noOfParkingSpaces;
    }

    public String getEircode() {
        return eircode;
    }

    public String getAddress() {
        return address;
    }

    public String getName() {
        return name;
    }

        /*

    --------------- SETTERS ------------
     */


    public void setAddress(String address) {
        this.address = address;
    }

    public void setNoOfParkingSpaces(int noOfParkingSpaces) {
        this.noOfParkingSpaces = noOfParkingSpaces;
    }

    public void setBooths(FunkyList<Booth> booths) {
        this.booths = booths;
    }

    public void setEircode(String eircode) {
        if (eircode.length() == 8 && eircode.substring(3).matches("[A-Z]{1}\\d{1,2}")) {

            this.eircode = eircode;
        } else {

            this.eircode = "This isn't applicable";
        }
    }

    public void setName(String name) {
        this.name = name;
    }

    /*
    ------------------ METHODS ---------------------
     */

    public void addBooth(String UID, int level, String accessibility) {
        booths.addElement(new Booth(UID, level, accessibility));

    }

    public String getBoothList() {

        return booths.printList();
    }

    public void removeBooth(int index) {

        booths.remove(index);

    }

    @Override
    public String toString() {
        return name + ".  and the address is: " + address + ".    " + "Eircode: " + eircode + ".   No.Of Parking Spaces: " + noOfParkingSpaces;
    }
}
