package ca;

class FunkyNode<N> {
    public FunkyNode<N> next=null;
    private N contents; //ADT reference!

    public FunkyNode(FunkyNode<N> head) {
    }

    public FunkyNode() {

    }

    public N getContents() { return contents; }
    public void setContents(N c) { contents=c; }
}
