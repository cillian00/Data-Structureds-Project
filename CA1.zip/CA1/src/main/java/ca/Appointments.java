package ca;

public class    Appointments {

    String date, time, vaccinationType,vaccinatorDetails,PPSN;
    Boolean status;
    FunkyList<Appointments> cert = new FunkyList<>();

    public Appointments(String date, String time, String vaccinationType, String vaccinatorDetails, String PPSN, Boolean status) {

        this.date = date;
        this.time = time;
        this.vaccinationType = vaccinationType;
        this.vaccinatorDetails = vaccinatorDetails;
        this.PPSN = PPSN;
        this.status = status;
        cert = new FunkyList<>();
    }


        /*

--------------- GETTERS ------------
*/

    public FunkyList<Appointments> getCert() {
        return cert;
    }

    public String getDate() {
        return date;
    }

    public String getPPSN() {
        return PPSN;
    }

    public String getTime() {
        return time;
    }

    public String getVaccinationType() {
        return vaccinationType;
    }

    public String getVaccinatorDetails() {
        return vaccinatorDetails;
    }

    public Boolean getStatus() {
        return status;
    }

    /*

    --------------- SETTERS ------------
     */

    public void setCert(FunkyList<Appointments> cert) {
        this.cert = cert;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setPPSN(String PPSN) {
     this.PPSN = PPSN;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public void setVaccinationType(String vaccinationType) {
        this.vaccinationType = vaccinationType;
    }

    public void setVaccinatorDetails(String vaccinatorDetails) {
        this.vaccinatorDetails = vaccinatorDetails;
    }

    public void setStatus(Boolean status) {
        this.status = status;
    }

    /*
    ------------------ METHODS ---------------------
     */

    public void addCert(String date, String time, String vaccinationType, String vaccinatorDetails, String PPSN, boolean status) {

        cert.addElement(new Appointments(date,time,vaccinationType,vaccinatorDetails,PPSN,status));

    }


    @Override
    public String toString() {
        return "Appointment: " + " " + " Date: " + date + "\n"
                + "Time: " + time + "\n"
                + "Type: " + vaccinationType + "\n"
                + "Details: " + vaccinatorDetails + "\n"
                + "Person's PPSN: " + PPSN + "\n"
                + "Status " + status
                +"\n";
    }
}

