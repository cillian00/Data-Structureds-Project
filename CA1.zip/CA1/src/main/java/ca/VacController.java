package ca;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.ListView;
import javafx.stage.Stage;


public class VacController {

@FXML
private TextField Name;
    @FXML
    private TextField Address;
    @FXML
    private TextField Eircode;
    @FXML
    private TextField noOfParkingSpaces;
    @FXML
    private Label Name1; // Name Label
    @FXML
    private Label Address1; // Address Label
    @FXML
    private Label Eircode1; // Eircode Label
    @FXML
    private Label noOfParkingSpaces1; // NoOfParkingSpaces Label
    @FXML
    private Button but; // Submit button
    @FXML
    private ListView<Label> list;

    private Main mc;


    public VacController() {


        start();

    }

    public void start() {

    }

    @FXML
    public void initialize() {

    }


    @FXML
    private void submitBut(ActionEvent e) {


      //  if (vaccinationCentreFunkyList.size() == 0) {

            addition();

    //    } else {   // Once we established that the array is greater than 0, we can run checks.

      //      while (vaccinationCentreFunkyList.size() > 0) {
        //        int i = 0;
          //      i++;

            //    if (vaccinationCentreFunkyList.get(i).getName().equals(name.getText())) {

              //      na.setText("Name has already been used.");
                //    start();

                }
               // else {
                 //   addition();
            //    }
          //  }
        //}
    //}


    @FXML public void mainMenu(ActionEvent e) throws Exception{

        FXMLLoader loader = new FXMLLoader(getClass().getResource("/Main.fxml"));
        Parent root = loader.load();

        Stage window = (Stage) but.getScene().getWindow();
        window.setScene(new Scene(root, 1119, 750));


    }


    public void addition() {

        String names = Name.getText();

        Name1.setText("Name:" + " " + names);
        String adr = Address.getText();
        Address1.setText("Address:" + " " + adr);
        if (Eircode.getText().length() == 8 && Eircode.getText().substring(0, 3).matches("[A-Z][0-9]{2}")) {

            String eircodes = Eircode.getText();
            Eircode1.setText("Eircode:" + " " + eircodes);

        } else {

            Eircode1.setText("Please Enter An Actual Eircode Eg: [X91 K90W]");

        }

        if (noOfParkingSpaces.getText().matches("[0-9]{1,2}")) {

            String numbers = noOfParkingSpaces.getText();
            noOfParkingSpaces1.setText("Number Of Parking Spaces:" + " " + numbers);


        } else {

            noOfParkingSpaces1.setText("Please Enter Numbers Only");

        }

        if (Eircode.getText().length() == 8 && Eircode.getText().substring(0, 3).matches("[A-Z][0-9]{2}") &&
                noOfParkingSpaces.getText().matches("[0-9]{1,2}")) {


            list.getItems().addAll(new Label("New Vaccination Centre --> " + "Name: " + Name.getText() + "  Address: " + Address.getText() + "  Eircode: " + Eircode.getText() + "  Spaces: " + noOfParkingSpaces.getText()));

            int l = Integer.parseInt(noOfParkingSpaces.getText());
            addVacCentre(Name.getText(), Address.getText(), Eircode.getText(), l);

        }

    }

    public void addVacCentre(String name, String address, String eircode, int spaces) {


        ApplicationV.mc.addVacCentre(name,address,eircode,spaces);
        System.out.println(" " + name + " " + address + " " + eircode + " " + spaces);

    }

    @FXML
    private void save(ActionEvent e) {

        try {
            ApplicationV.mc.saveVacCentres();
        } catch (Exception E) {

            System.out.println("Can't save!");


        }
    }

    @Override
    public String toString() {
        return "HelloController{" +
                "name=" + Name +
                ", address=" + Address +
                ", eircode=" + Eircode +
                ", noOfParkingSpaces=" + noOfParkingSpaces +
                '}';
    }
}