package ca;


public class Booth {

    String UID;
    String accessibility;

    int level;
    FunkyList<Appointments> appointments = new FunkyList<>();

    public Booth(String UID, int level, String accessibility) {

        this.UID = UID;
        this.level = level;
        this.accessibility = accessibility;
        appointments = new FunkyList<>();
    }



    public void addAppointment(String date, String time, String vaccinationType, String vaccinatorDetails, String PPSN, boolean status) {

        appointments.addElement(new Appointments(date,time,vaccinationType,vaccinatorDetails,PPSN,status));

    }

      /*

    --------------- GETTERS ------------
     */

    public FunkyList<Appointments> getAppointments() {
        return appointments;
    }

    public int getLevel() {
        return level;
    }

    public String getAccessibility() {
        return accessibility;
    }

    public String getUID() {
        return UID;
    }

    /*

    --------------- SETTERS ------------
     */

    public void setAccessibility(String accessibility) {
        this.accessibility = accessibility;
    }

    public void setAppointments(FunkyList<Appointments> appointments) {
        this.appointments = appointments;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public void setUID(String UID) {
        this.UID = UID;
    }

    /*
    ------------------ METHODS ---------------------
     */


    public String getAppointmentList() {

        return appointments.printList();
    }



    @Override
    public String toString() {
        return "Booth ID: " + UID + " " + "  Floor Level: " + level + ".  " + "Accessibility Info: " + accessibility ;
    }

}
