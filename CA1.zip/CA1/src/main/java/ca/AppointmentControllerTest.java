package ca;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;



class AppointmentControllerTest {

    Appointments mc;
    @BeforeEach
     void setUp() {

        mc = new Appointments("","","","","",false);

    }

    @Test
    void getDate() {


    //    assertTrue(a);


    }
}